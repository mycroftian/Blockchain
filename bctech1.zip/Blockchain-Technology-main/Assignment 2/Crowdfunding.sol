// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract Crowdfunding {
    
    address payable public projectOwner;
    uint256 public targetAmount;
    uint256 public endTime;
    uint256 public raisedAmount;
    string public title;
    string public description;
    bool public withdrawn;
    
    mapping(address => uint256) public pledges;
    address[] public supporters;
    mapping(address => bool) public hasSupported;
    
    uint256 public constant MIN_PLEDGE = 0.001 ether;
    
    event Pledged(address indexed supporter, uint256 amount, uint256 total);
    event Withdrawn(address indexed owner, uint256 amount, uint256 time);
    event Refunded(address indexed supporter, uint256 amount, uint256 time);
    event Extended(uint256 oldEnd, uint256 newEnd);
    event Cancelled(uint256 time, uint256 refunded);
    
    modifier onlyOwner() {
        require(msg.sender == projectOwner, "not owner");
        _;
    }
    
    modifier beforeEnd() {
        require(block.timestamp < endTime, "campaign ended");
        _;
    }
    
    modifier afterEnd() {
        require(block.timestamp >= endTime, "still active");
        _;
    }
    
    constructor(uint256 _target, uint256 _durationInMinutes, string memory _title, string memory _desc) {
        require(_target > 0 && _durationInMinutes > 0 && bytes(_title).length > 0, "invalid params");
        
        projectOwner = payable(msg.sender);
        targetAmount = _target;
        endTime = block.timestamp + (_durationInMinutes * 1 minutes);
        title = _title;
        description = _desc;
    }
    
    function contribute() public payable beforeEnd {
        require(msg.value >= MIN_PLEDGE && msg.sender != projectOwner, "invalid contribution");
        
        if (!hasSupported[msg.sender]) {
            supporters.push(msg.sender);
            hasSupported[msg.sender] = true;
        }
        
        pledges[msg.sender] += msg.value;
        raisedAmount += msg.value;
        
        emit Pledged(msg.sender, msg.value, raisedAmount);
    }
    
    function withdraw() public onlyOwner afterEnd {
        require(raisedAmount >= targetAmount && !withdrawn, "cannot withdraw");
        
        withdrawn = true;
        uint256 bal = address(this).balance;
        
        emit Withdrawn(projectOwner, bal, block.timestamp);
        
        (bool sent, ) = projectOwner.call{value: bal}("");
        require(sent, "transfer failed");
    }
    
    function refund() public afterEnd {
        require(raisedAmount < targetAmount, "goal reached");
        uint256 amount = pledges[msg.sender];
        require(amount > 0, "nothing to refund");
        
        pledges[msg.sender] = 0;
        
        emit Refunded(msg.sender, amount, block.timestamp);
        
        (bool sent, ) = payable(msg.sender).call{value: amount}("");
        require(sent, "refund failed");
    }
    
    function extendTime(uint256 _minutes) public onlyOwner {
        require(block.timestamp < endTime && _minutes > 0 && _minutes <= 43200, "cannot extend"); // 30 days in minutes
        require(raisedAmount < targetAmount, "already funded");
        
        uint256 prev = endTime;
        endTime += (_minutes * 1 minutes);
        
        emit Extended(prev, endTime);
    }
    
    function checkGoal() public view returns (bool) {
        return raisedAmount >= targetAmount;
    }
    
    function checkEnded() public view returns (bool) {
        return block.timestamp >= endTime;
    }
    
    function supporterCount() public view returns (uint256) {
        return supporters.length;
    }
    
    receive() external payable {
        require(block.timestamp < endTime && msg.value >= MIN_PLEDGE && msg.sender != projectOwner, "invalid");
        
        if (!hasSupported[msg.sender]) {
            supporters.push(msg.sender);
            hasSupported[msg.sender] = true;
        }
        
        pledges[msg.sender] += msg.value;
        raisedAmount += msg.value;
        
        emit Pledged(msg.sender, msg.value, raisedAmount);
    }
    
    fallback() external payable {
        revert("use contribute()");
    }
}
