# Decentralized Crowdfunding Smart Contract

## Overview

A decentralized crowdfunding platform that enables transparent fundraising without intermediaries. Funds are released to the creator only if the goal is met, otherwise, backers receive full refunds.

## Core Functions

### `constructor(uint256 _target, uint256 _durationInMinutes, string memory _title, string memory _desc)`

Initializes the campaign with a funding goal, duration in minutes, title, and description.

### `contribute()`

Allows backers to contribute ETH to the campaign (minimum 0.001 ETH). The campaign must be active.

### `withdraw()`

The project owner withdraws all funds after the deadline if the funding goal has been reached.

### `refund()`

Backers can reclaim their contributions after the deadline if the funding goal is NOT reached.

### `extendTime(uint256 _minutes)`

The project owner can extend the campaign duration (up to 30 days worth of minutes) if the goal has not yet been met and the campaign is still active.

---

## View Functions

- `checkGoal()` - Returns true if the funding goal has been met.
- `checkEnded()` - Returns true if the campaign deadline has passed.
- `supporterCount()` - Returns the total number of backers.

---

## Campaign Flow

### Successful Campaign

1.  The project owner deploys the contract with a goal (e.g., 10 ETH) and a duration (e.g., 43200 minutes for 30 days).
2.  Backers contribute until the goal is reached or exceeded (e.g., 11 ETH total).
3.  The deadline passes.
4.  The project owner calls `withdraw()` and receives all the funds.
5.  Backers cannot claim refunds because the goal was met.

### Failed Campaign

1.  The project owner deploys the contract with a goal (e.g., 10 ETH) and a duration (e.g., 43200 minutes).
2.  Backers contribute, but the goal is not reached by the deadline (e.g., only 6.5 ETH is raised).
3.  The deadline passes.
4.  The project owner cannot withdraw the funds because the goal was not met.
5.  Each backer calls `refund()` to get their exact contribution back.

---

## Security Features

- **Re-entrancy Protection**: Follows the checks-effects-interactions pattern to prevent re-entrancy attacks.
- **Double Withdrawal Prevention**: A boolean flag `withdrawn` prevents the owner from withdrawing funds more than once.
- **Access Control**: A `onlyOwner` modifier restricts sensitive functions to the project owner.
- **Time-based Logic**: `beforeEnd` and `afterEnd` modifiers ensure functions are called only within the correct campaign phase.
- **Safe Transfers**: Uses the low-level `call()` method for sending ETH, which is the recommended safe practice.

---

## Testing on Remix IDE

### Setup

1.  Open [Remix IDE](https://remix.ethereum.org).
2.  Create a new file named `Crowdfunding.sol` and paste the contract code.
3.  Compile the contract with a Solidity version of `0.8.20` or higher.
4.  In the "Deploy & Run Transactions" tab, select the "Remix VM (Shanghai)" environment.
5.  Deploy the contract with the following parameters:
    - `_target`: `10000000000000000000` (10 ETH in Wei)
    - `_durationInMinutes`: `60` (for a 1-hour campaign)
    - `_title`: "My Awesome Project"
    - `_description`: "A description of my awesome project."

### Test Successful Campaign

1.  Switch to a different account (not the owner).
2.  In the `contribute` function, enter `5` ETH in the value field and transact.
3.  Switch to another account and contribute `6` ETH.
4.  Verify that `raisedAmount` is `11 ETH` and `checkGoal()` returns `true`.
5.  Once the `endTime` has passed, switch back to the owner's account and call `withdraw()`.
6.  Verify that the owner's account balance has increased by 11 ETH.

### Test Failed Campaign

1.  Deploy a new instance of the contract.
2.  Contribute a total of `5` ETH from one or more accounts.
3.  Once the `endTime` has passed, verify that `checkGoal()` returns `false`.
4.  Each backer calls `refund()` to receive their contribution back.
5.  Verify that the backers' balances are restored.

---

## Deployment

### Constructor Parameters

- `_target`: The funding goal in Wei (e.g., `10000000000000000000` for 10 ETH).
- `_durationInMinutes`: The duration of the campaign in minutes (e.g., `43200` for 30 days).
- `_title`: The title of the campaign.
- `_description`: A brief description of the campaign.
